var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["cc9faada-59b8-438e-a36d-a15e2495abb8","9d0c8105-0030-4d5b-b441-84131ab06782"],"propsByKey":{"cc9faada-59b8-438e-a36d-a15e2495abb8":{"name":"1083545.png_1","sourceUrl":"assets/v3/animations/H8tUi1qKtQTNSCavmNJvQxnThF9wTCzLbr8ZRNzmqw0/cc9faada-59b8-438e-a36d-a15e2495abb8.png","frameSize":{"x":512,"y":511},"frameCount":1,"looping":true,"frameDelay":4,"version":"BeRWeorBbruT85iQoRXckRhQtJhZqklO","loadedFromSource":true,"saved":true,"sourceSize":{"x":512,"y":511},"rootRelativePath":"assets/v3/animations/H8tUi1qKtQTNSCavmNJvQxnThF9wTCzLbr8ZRNzmqw0/cc9faada-59b8-438e-a36d-a15e2495abb8.png"},"9d0c8105-0030-4d5b-b441-84131ab06782":{"name":"image_processing20210530-30965-83omtl.png_1","sourceUrl":"assets/v3/animations/H8tUi1qKtQTNSCavmNJvQxnThF9wTCzLbr8ZRNzmqw0/9d0c8105-0030-4d5b-b441-84131ab06782.png","frameSize":{"x":800,"y":800},"frameCount":1,"looping":true,"frameDelay":4,"version":"YPoU8FdxF7ffvFq7n61oRiNRqqgtLsg4","loadedFromSource":true,"saved":true,"sourceSize":{"x":800,"y":800},"rootRelativePath":"assets/v3/animations/H8tUi1qKtQTNSCavmNJvQxnThF9wTCzLbr8ZRNzmqw0/9d0c8105-0030-4d5b-b441-84131ab06782.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var life = 0;
var rock1, rock2, rock3 ,rock4;
var boundary1, boundary2;
var spaceship;

  boundary1 = createSprite(190,120,420,3);
  boundary2 = createSprite(190,260,420,3);
  
  spaceship = createSprite(20,190,13,13);
  spaceship.setAnimation("image_processing20210530-30965-83omtl.png_1");
  spaceship.scale=0.08;
  rock1 = createSprite(100,130,10,10);
  rock1.setAnimation("1083545.png_1");
  rock1.scale=0.06;
  rock2 = createSprite(215,130,10,10);
  rock2.setAnimation("1083545.png_1");
   rock2.scale=0.06;
  rock3 = createSprite(165,250,10,10);
  rock3.setAnimation("1083545.png_1");
   rock3.scale=0.06;
  rock4 = createSprite(270,250,10,10);
  rock4.setAnimation("1083545.png_1");
   rock4.scale=0.06;
 



rock1.velocityY=4;
rock2.velocityY=4;
rock3.velocityY=-4;
rock4.velocityY=-4;



function draw() {
   background("white");
  text("Lives: " + life,200,100);
  strokeWeight(0);
  fill("lightblue");
  rect(0,120,52,140);
  fill("yellow");
  rect(345,120,52,140);
  

  
 drawSprites();
 rock1.bounceOff(boundary1);
rock1.bounceOff(boundary2);
rock2.bounceOff(boundary1);
rock2.bounceOff(boundary2);
rock3.bounceOff(boundary1);
rock3.bounceOff(boundary2);
rock4.bounceOff(boundary1);
rock4.bounceOff(boundary2);

if (keyDown("right")){
  spaceship.velocityX=3;
}
if (keyDown("left")){
  spaceship.velocityX=-3;
}

if (spaceship.isTouching(rock1)||spaceship.isTouching(rock2)||spaceship.isTouching(rock3)||spaceship.isTouching(rock4)){
  spaceship.x=20;
  spaceship.y=190;
  life = life+1;
}


}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
